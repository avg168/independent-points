'use strict';
const fs = require('node:fs');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.join(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const solidity = read('contracts/IndependentPoints.sol');
const html = read('web/index.html');
const app = read('web/app.js');
const demoHtml = read('web/demo.html');
const demoJs = read('web/demo.js');
const demoCore = read('web/demo-core.js');
for (const f of ['app.js','index.html','styles.css','demo.html','demo.js','demo-core.js','receipt-core.js','tx-core.js','confirmation-core.js','pending-core.js','preflight-core.js']) {
  assert.equal(read('web/' + f), read('docs/' + f), `${f} differs from GitHub Pages docs copy`);
}
for (const fn of ['mint','burn','pause','unpause']) assert.match(solidity, new RegExp(`function ${fn}\\(`));
assert.match(solidity, /function mint\([^\n]*onlyOwner/);
assert.match(solidity, /ERC20Capped/);
assert.match(solidity, /ERC20Pausable/);
assert.match(solidity, /override\(ERC20, ERC20Capped, ERC20Pausable\)/);
for(const match of [/11155111n/, /eth_requestAccounts/, /tx\.wait\(1\)/, /REQUIRED_CONFIRMATIONS = 3/, /PointsConfirmationCore.assess/, /contract\.transfer\(to, amount\)/, /contract\.mint\(to, amount\)/, /contract\.burn\(amount\)/, /contract\.queryFilter/, /contract\.pause\(\)/, /contract\.unpause\(\)/, /independent-points-v07-contract/]) assert.match(app, match);
assert.match(html, /href="\.\/demo\.html"/);
for (const id of ['currentAccount','balance','supply','externalBalance','receiver','resetBtn','transferForm','issueForm','withdrawForm','history','status','storageHint','backupBtn','restoreInput','exportCsvBtn']) {
  assert.match(demoHtml, new RegExp(`id="${id}"`));
  assert.match(demoJs, new RegExp(`(?:el|handle)\\('${id}'`));
}
for (const id of ['pendingBtn','pendingList','lookupForm','lookupHash','lookupBtn','lookupResult','lookupLink','burnForm','burnAmount','burnBtn']) assert.match(html, new RegExp(`id="${id}"`));
for (const id of ['filterAccount','filterType','historyCount','verifyBtn','verifyResult']) assert.match(demoHtml, new RegExp(`id="${id}"`));
assert.match(app, /getTransactionReceipt\(hash\)/);
assert.match(app, /PointsReceiptCore.verifyReceipt/);
assert.match(app, /PointsTxCore.verifyExpectedTransfer/);
assert.match(app, /getTransactionReceipt\(tx.hash\)/);
for (const id of ['exportPendingBtn','importPendingInput']) assert.match(html, new RegExp(`id=\"${id}\"`));
assert.match(app, /PointsPendingCore.findDuplicate/);
assert.match(app, /PointsPendingCore.importTracking/);
assert.match(read('web/receipt-core.js'), /verifyReceipt/);
assert.match(demoHtml, /並非區塊鏈/);
assert.match(demoJs, /未上鏈/);
assert.match(demoCore, /NOT blockchain/);
assert.doesNotMatch(html + app + demoHtml + demoJs + demoCore + solidity, /009|L-VVIP|CV 貢獻值/);
for (const id of ['currentOwnerLabel','pendingOwnerLabel','newOwnerAddress','proposeOwnerForm','proposeOwnerBtn','acceptOwnerBtn']) {
  assert.match(html, new RegExp(`id="${id}"`));
  assert.match(app, new RegExp(`(?:el\\("${id}"\\)|id=\\"${id}\\")`));
}
for (const method of ['pendingOwner', 'transferOwnership', 'acceptOwnership', 'OwnershipTransferStarted', 'OwnershipTransferred']) assert.ok(app.includes(method));
console.log('PASS: V1.0 website copies, separation, two-step ownership interface and existing controls.');
console.log('NOTE: Actual browser wallet, Solidity compilation and on-chain transactions remain untested.');

for(const id of ["recipientCheckBtn", "recipientCheckResult", "contractExplorerLink", "remainingLabel"]) assert.match(html, new RegExp(`id="${id}"`));
assert.match(app, /contract\.transfer\.staticCall/);
assert.match(app, /contract\.mint\.staticCall/);
assert.match(app, /contract\.burn\.staticCall/);
