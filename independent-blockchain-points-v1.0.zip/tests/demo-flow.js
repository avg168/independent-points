'use strict';
const assert = require('node:assert/strict');
const { createLedger, parseAmount, formatAmount } = require('../web/demo-core.js');
function shouldFail(action, hint) { assert.throws(action, error => error instanceof Error && error.message.includes(hint)); }
let checks = 0;
function test(name, action) { action(); checks += 1; console.log(`PASS: ${name}`); }
test('two-decimal parser preserves exact integers', () => {
  assert.equal(parseAmount('0.01'), 1n);
  assert.equal(parseAmount('12.50'), 1250n);
  assert.equal(formatAmount(1250n), '12.50');
  assert.equal(formatAmount(-1n), '-0.01');
});
test('invalid, zero and high-precision values are rejected', () => {
  for (const s of ['-1','1.001','1,000','1e3','','0x5']) shouldFail(() => parseAmount(s), '請輸入正數');
  for (const s of ['0','0.00']) shouldFail(() => parseAmount(s), '大於 0');
});
test('one transfer debits sender and credits recipient, keeping supply unchanged', () => {
  const ledger = createLedger();
  const before = ledger.snapshot();
  const evt = ledger.transfer('Alice', 'Bob', '12.50');
  const after = ledger.snapshot();
  assert.equal(evt.id, 'SIM-0001');
  assert.equal(after.balances.Alice, '98750');
  assert.equal(after.balances.Bob, '1250');
  assert.equal(after.supply, before.supply);
  assert.equal(after.history.length, 1);
});
test('insufficient balance, self-transfer and external withdrawal source are blocked', () => {
  const ledger = createLedger();
  shouldFail(() => ledger.transfer('Bob', 'Alice', '0.01'), '不足');
  shouldFail(() => ledger.transfer('Alice', 'Alice', '1'), '同一個');
  shouldFail(() => ledger.transfer('External', 'Alice', '1'), '不支援');
  assert.equal(ledger.snapshot().history.length, 0);
});
test('issue increases both supply and target balance; cap is enforced', () => {
  const ledger = createLedger();
  const before = ledger.snapshot();
  const issue = ledger.issue('Bob', '0.01');
  const after = ledger.snapshot();
  assert.equal(issue.type, '管理者發行（模擬存入）');
  assert.equal(BigInt(after.supply) - BigInt(before.supply), 1n);
  assert.equal(after.balances.Bob, '1');
  shouldFail(() => ledger.issue('Alice', '1000000000.00'), '上限');
  assert.equal(ledger.snapshot().history.length, 1);
});
test('external transfer reduces member balance but not total supply', () => {
  const ledger = createLedger();
  ledger.transfer('Alice', 'External', '5.00');
  const s = ledger.snapshot();
  assert.equal(s.balances.Alice, '99500');
  assert.equal(s.balances.External, '500');
  assert.equal(s.supply, '100000');
});
test('ledger instances isolate state and snapshot edits do not mutate ledger', () => {
  const x = createLedger(); const y = createLedger();
  x.transfer('Alice', 'Bob', '1.00');
  const copy = x.snapshot();
  shouldFail(() => { copy.balances.Bob = '999999'; }, 'read only');
  copy.history[0].units = '999999';
  assert.equal(x.snapshot().balances.Bob, '100');
  assert.equal(x.snapshot().history[0].units, '100');
  assert.equal(y.snapshot().balances.Bob, '0');
});
console.log(`PASS: ${checks} independent demo ledger flow tests.`);
