'use strict';
const assert = require('node:assert/strict');
const { createLedger } = require('../web/demo-core.js');
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS: ' + name); }
function reject(fn) { assert.throws(fn, Error); }
test('export and restore the full transaction history and balances', () => {
  const a = createLedger();
  a.transfer('Alice', 'Bob', '12.50');
  a.issue('Bob', '99.99');
  a.transfer('Bob', 'External', '2.01');
  const exported = JSON.parse(JSON.stringify(a.snapshot()));
  assert.deepEqual(createLedger(exported).snapshot(), a.snapshot());
});
test('restored ledger supports continuation with next transaction ID', () => {
  const a = createLedger(); a.transfer('Alice', 'Bob', '1.00');
  const b = createLedger(JSON.parse(JSON.stringify(a.snapshot())));
  assert.equal(b.transfer('Bob', 'Alice', '0.01').id, 'SIM-0002');
  assert.equal(b.snapshot().balances.Alice, '99901');
});
test('rejects incorrect balances and mismatching transaction IDs', () => {
  const a = createLedger(); a.issue('Alice', '1.00');
  const changed = JSON.parse(JSON.stringify(a.snapshot())); changed.balances.Alice = '999999';
  reject(() => createLedger(changed));
  const changedId = a.snapshot(); changedId.history[0].id = 'SIM-5000';
  reject(() => createLedger(changedId));
});
test('rejects an invented withdrawal from External, altered supply and unknown type', () => {
  const a = createLedger(); a.transfer('Alice', 'External', '5.00');
  const altered = a.snapshot(); altered.history[0].from = 'External';
  reject(() => createLedger(altered));
  const supply = a.snapshot(); supply.supply = '0';
  reject(() => createLedger(supply));
  const type = a.snapshot(); type.history[0].type = '真實鏈上轉帳';
  reject(() => createLedger(type));
});
test('rejects excessive event count, unknown format and malformed numeric units', () => {
  const a = createLedger(); a.transfer('Alice', 'Bob', '1.00');
  const history = a.snapshot(); history.history = Array.from({length: 1001}, () => history.history[0]);
  reject(() => createLedger(history));
  const version = a.snapshot(); version.version = 99; reject(() => createLedger(version));
  const units = a.snapshot(); units.history[0].units = '1e3'; reject(() => createLedger(units));
});
console.log(`PASS: ${passed} demonstration persistence and import integrity tests.`);
