'use strict';
const assert = require('node:assert/strict');
const { verifyReceipt } = require('../web/receipt-core.js');
const contract = '0x' + 'a'.repeat(40), wallet = '0x' + 'b'.repeat(40), third = '0x' + 'c'.repeat(40);
const transfer = (address, from, to, value, name = 'Transfer') => ({address, decoded: {name,args:[from,to,value]}});
const decode = log => log.decoded;
const format = v => (v / 100n) + '.' + (v % 100n).toString().padStart(2, '0');
const go = receipt => verifyReceipt(receipt, contract, wallet, decode, format);
assert.equal(go(null).state, 'pending');
assert.equal(go({status:0,blockNumber:88,logs:[transfer(contract,third,wallet,100n)]}).state,'failed');
assert.equal(go({status:0,blockNumber:88,logs:[transfer(contract,third,wallet,100n)]}).events.length,0);
const ok = {status:1,blockNumber:99,logs:[
  transfer(third,third,wallet,999999n), // other contract: not IPT
  transfer(contract,third,wallet,1250n), // incoming
  transfer(contract,wallet,third,500n), // outgoing
  transfer(contract,third,third,700n), // unrelated wallet
  transfer(contract,third,wallet,0n), // no actual point movement
  transfer(contract,third,wallet,100n,'Approval'), // not a Transfer
  {address:contract,decoded:null},
  {address:contract,get decoded(){throw Error('bad log');}}
]};
assert.equal(go(ok).state,'success');
assert.equal(go(ok).events.length,2);
assert.deepEqual(go(ok).events.map(x=>x.amount),['12.50','5.00']);
assert.equal(go({status:1,blockNumber:100,logs:[]}).events.length,0);
console.log('PASS: transaction receipt tests — pending, failed, matching contract/wallet and nonzero Transfer filtering.');
