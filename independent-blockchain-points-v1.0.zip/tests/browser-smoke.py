from playwright.sync_api import sync_playwright
from pathlib import Path
import re
fake = r'''
const A='0x'+'1'.repeat(40), B='0x'+'2'.repeat(40), T='0x'+'3'.repeat(40);
window.ethereum={on(){}};
class FakeProvider {
 async send(){return [A]}; async getNetwork(){return {chainId:11155111n}};
 async getSigner(){return {getAddress:async()=>A}};
 async getCode(a){return (a.toLowerCase()===T.toLowerCase()||a.toLowerCase()===('0x'+'4'.repeat(40)))?'0x6000':'0x'};
 async getBlockNumber(){return 103};
}
class FakeContract {
 constructor(address){this.target=address;this.interface={parseLog:()=>({name:'Transfer',args:[A,B,150n]})};
 this.filters={Transfer:()=>({})};
 this.transfer=(to, units)=>Promise.resolve({hash:'0x'+'a'.repeat(64),wait:async()=>({hash:'0x'+'a'.repeat(64),status:1,blockNumber:100,logs:[{address:T,topics:[],data:'0x'}]})});
 this.transfer.staticCall=async()=>true;
 this.mint=async()=>{};this.mint.staticCall=async()=>{};
 this.burn=async()=>{};this.burn.staticCall=async()=>{};
 }
 async name(){return 'Independent Points'};async symbol(){return 'IPT'};async decimals(){return 2n};
 async cap(){return 100000000000n};async MAX_POINTS(){return 1000000000n};
 async balanceOf(){return 10000n}; async totalSupply(){return 100000n};
 async owner(){return A};async pendingOwner(){return '0x'+'0'.repeat(40)};async paused(){return false};
 async queryFilter(){return []};
}
window.ethers={BrowserProvider:FakeProvider,Contract:FakeContract,
 isAddress:x=>/^0x[\da-fA-F]{40}$/.test(x),getAddress:x=>x,
 parseUnits:(s,dec)=>{const [a,b='']=s.split('.');return BigInt(a)*(10n**BigInt(dec))+BigInt(b.padEnd(dec,'0'));},
 formatUnits:(v,dec)=>{const u=10n**BigInt(dec),x=BigInt(v),f=String(x%u).padStart(dec,'0').replace(/0+$/,'');return `${x/u}${f?'.'+f:''}`;}};
'''
with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=browser.new_page()
  errors=[]
  page.on('pageerror',lambda err:errors.append(str(err)))
  webroot=Path(__file__).resolve().parent.parent / 'web'
  html=re.sub(r'<script\b[^>]*></script>', '', (webroot/'index.html').read_text(),flags=re.I)
  page.set_content(html)
  page.evaluate(fake)
  for filename in ['receipt-core.js','tx-core.js','confirmation-core.js','pending-core.js','preflight-core.js','app.js']:
    page.add_script_tag(content=(webroot/filename).read_text())
  assert page.title().startswith('Independent Points V1.0')
  page.locator('#contractAddress').fill('0x'+'3'*40)
  page.locator('#connectBtn').click()
  page.locator('#balanceLabel').get_by_text('100').wait_for()
  assert page.locator('#remainingLabel').inner_text()=='999999000 IPT',page.locator('#remainingLabel').inner_text()
  page.locator('#sendTo').fill('0x'+'2'*40)
  page.locator('#recipientCheckBtn').click()
  assert '沒有合約程式碼' in page.locator('#recipientCheckResult').inner_text()
  page.locator('#sendAmount').fill('1.50')
  page.once('dialog',lambda dialog: dialog.accept())
  page.locator('#sendBtn').click()
  page.locator('#status').get_by_text('符合預期事件',exact=False).wait_for(timeout=5000)
  page.locator('#sendTo').fill('0x'+'3'*40)
  page.locator('#recipientCheckBtn').click()
  assert '不能直接轉帳給本 IPT 合約' in page.locator('#recipientCheckResult').inner_text()
  page.locator('#sendTo').fill('0x'+'4'*40)
  page.locator('#recipientCheckBtn').click()
  assert '智慧合約地址' in page.locator('#recipientCheckResult').inner_text()
  assert not errors,errors
  print('PASS: Chromium wallet mock connected; supply display, EOA preview, 1.50 transfer receipt, own token contract blocked, contract recipient warning, no page JS errors.')
  browser.close()

